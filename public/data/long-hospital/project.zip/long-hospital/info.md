# long-hospital
https://iiif.wellcomecollection.org/presentation/collections/genres/Stickers
